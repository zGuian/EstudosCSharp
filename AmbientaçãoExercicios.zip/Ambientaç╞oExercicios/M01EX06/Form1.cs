namespace M01EX06
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int nasc;
            int.TryParse(txtBox.Text, out nasc);
            int atual = DateTime.Now.Year;
            int idade = atual - nasc;

            // MENSAGENS 
            lblMsg1.Text = $"Voce digitou {nasc}"; // mensagem 1
            lblMsg2.Text = $"Estamos no ano de {atual}"; // mensagem 2
            lblMsg3.Text = $"Quem nasceu em {nasc} vai ter {idade} anos"; // mensagem 3

            panResultado.Visible = true;
        }
    }
}