﻿class Program
{
    static void Main(string[] args)
    { 
        Console.Write("\nEm que ano você nasceu? ");
        int nasc;
        int.TryParse(Console.ReadLine(), out nasc);
        int atual = DateTime.Now.Year;
        int idade = atual - nasc;

        // MOSTRANDO RESULTADOS
        Console.WriteLine("-------------------------------------------");
        Console.WriteLine($"Estamos atualmente em {DateTime.Now.Year}");
        Console.Write($"Se voce nasceu em {nasc} você vai ter {idade}");
        Console.ReadKey();
    }
}