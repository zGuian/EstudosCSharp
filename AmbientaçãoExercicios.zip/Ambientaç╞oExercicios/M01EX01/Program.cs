﻿class Program
{
    static void Main(string[] args)
    {
        //string n1 = " MEU ";
        //string n2 = " BRASIL ";
        //string n3 = " BRASILEIRO ";

        Thread.Sleep(1000);
        Console.BackgroundColor = ConsoleColor.Blue;
        Console.ForegroundColor = ConsoleColor.White;
        Console.SetCursorPosition(10, 4);
        Console.Write(" MEU ");
        Console.ResetColor();
        //Console.Write(n1);
        
        Thread.Sleep(1000);
        Console.BackgroundColor = ConsoleColor.White;
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write(" BRASIL ");
        Console.ResetColor();
        //Console.Write(n2);

        Thread.Sleep(1000);
        Console.BackgroundColor = ConsoleColor.Green;
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine(" BRASILEIRO ");
        Console.ResetColor();
        //Console.Write(n3);

        Console.ReadKey();
        Console.BackgroundColor = ConsoleColor.Black;


    }
}