namespace M01EX04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblMsg3_Click(object sender, EventArgs e)
        {

        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            float num = 0f;
            float.TryParse(txtBox.Text, out num);

            int n1 = (int)num;
            int n2 = Convert.ToInt16(num);

            lblMsg1.Text = $"Voc� digitou {num:N3}";
            lblMsg2.Text = $"A parte inteira � {n1:D}";
            lblMsg3.Text = $"Arredondando temos {n2:D}";
            panResultado.Visible = true;
        }

        private void lblMsg1_Click(object sender, EventArgs e)
        {

        }
    }
}