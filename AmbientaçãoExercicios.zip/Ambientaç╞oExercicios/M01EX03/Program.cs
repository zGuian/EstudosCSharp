﻿class Program
{
    static void Main(string[] args)
    {
        Console.Write("\nDigite um número Real: ");
        float num;
        float.TryParse(Console.ReadLine(), out num);

        int n1 = (int)num;
        int n2 = Convert.ToInt16(num);

        Console.WriteLine("-------------------------------------------");
        Console.WriteLine($"Você digitou o valor {num:N}");
        Console.WriteLine($"A parte inteira do número {num} é {n1:D}");
        Console.WriteLine($"Arredondando, temos o número {n2:D}");
        Console.ReadKey();
    }
}