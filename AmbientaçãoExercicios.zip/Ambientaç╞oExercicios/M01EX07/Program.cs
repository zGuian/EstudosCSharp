﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("\nSORTEADOR DE NÚMERO");
        Console.WriteLine("------------------------------");

        int ini, fim;

        Console.Write("Inicio: ");
        int.TryParse(Console.ReadLine(), out ini);
        Console.Write("Fim: ");
        int.TryParse(Console.ReadLine(), out fim);
        Console.WriteLine("------------------------------");

        Console.WriteLine("SORTEANDO...");
        Thread.Sleep(2000);
        Console.SetCursorPosition(0, 6);
        Random gerador = new Random();
        int num = gerador.Next(ini, fim + 1);
        Console.WriteLine($"Entre {ini} e {fim} sorteei o valor {num}");

        
        Console.ReadKey();
    }
}