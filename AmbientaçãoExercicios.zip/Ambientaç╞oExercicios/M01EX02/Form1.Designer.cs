﻿namespace M01EX02
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIniciar = new System.Windows.Forms.Button();
            this.lblMsg1 = new System.Windows.Forms.Label();
            this.lblMsg2 = new System.Windows.Forms.Label();
            this.lblMsg3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIniciar
            // 
            this.btnIniciar.Location = new System.Drawing.Point(56, 88);
            this.btnIniciar.Name = "btnIniciar";
            this.btnIniciar.Size = new System.Drawing.Size(161, 45);
            this.btnIniciar.TabIndex = 0;
            this.btnIniciar.Text = "INICIAR";
            this.btnIniciar.UseVisualStyleBackColor = true;
            this.btnIniciar.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblMsg1
            // 
            this.lblMsg1.Location = new System.Drawing.Point(12, 9);
            this.lblMsg1.Name = "lblMsg1";
            this.lblMsg1.Size = new System.Drawing.Size(70, 35);
            this.lblMsg1.TabIndex = 1;
            this.lblMsg1.Text = "MEU";
            this.lblMsg1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMsg1.Visible = false;
            // 
            // lblMsg2
            // 
            this.lblMsg2.Location = new System.Drawing.Point(88, 9);
            this.lblMsg2.Name = "lblMsg2";
            this.lblMsg2.Size = new System.Drawing.Size(96, 35);
            this.lblMsg2.TabIndex = 2;
            this.lblMsg2.Text = "BRASIL";
            this.lblMsg2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMsg2.Visible = false;
            // 
            // lblMsg3
            // 
            this.lblMsg3.Location = new System.Drawing.Point(190, 9);
            this.lblMsg3.Name = "lblMsg3";
            this.lblMsg3.Size = new System.Drawing.Size(81, 35);
            this.lblMsg3.TabIndex = 3;
            this.lblMsg3.Text = "BRASILEIRO";
            this.lblMsg3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMsg3.Visible = false;
            this.lblMsg3.Click += new System.EventHandler(this.lblMsg3_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.btnIniciar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(283, 155);
            this.Controls.Add(this.lblMsg3);
            this.Controls.Add(this.lblMsg2);
            this.Controls.Add(this.lblMsg1);
            this.Controls.Add(this.btnIniciar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnIniciar;
        private Label lblMsg1;
        private Label lblMsg2;
        private Label lblMsg3;
    }
}