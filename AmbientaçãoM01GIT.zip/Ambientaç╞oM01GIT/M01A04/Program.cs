﻿namespace M01A04
{
    class Program
    {
        static void Main(string[] args)
        {
            // Valores numéricos Inteiros
            Console.WriteLine("O Tipo byte vai de " + byte.MinValue + " ate " + byte.MaxValue);     // 0 a 255
            Console.WriteLine("O Tipo sbyte vai de " + sbyte.MinValue + " ate " + sbyte.MaxValue);      // Mesma função do byte recomendado quando for negativo (-128 ate 127)
            Console.WriteLine("O Tipo short vai de " + short.MinValue + " ate " + short.MaxValue);      // Equivalente a 32767 2byte CONTA NEGATIVO
            Console.WriteLine("O Tipo ushort vai de " + ushort.MinValue + " ate " + ushort.MaxValue);       // Equivalente a 65535 NÃO CONTA NEGATIVO
            Console.WriteLine("O Tipo int vai de " + int.MinValue + " ate " + int.MaxValue);        //
            Console.WriteLine("O Tipo uint vai de " + uint.MinValue + " ate " + uint.MaxValue);     //
            Console.WriteLine("O Tipo long vai de " + long.MinValue + " ate " + long.MaxValue);     //
            Console.WriteLine("O Tipo ulong vai de " + ulong.MinValue + " ate " + ulong.MaxValue);      // 
            // Valores numéricos Reais
            Console.WriteLine("O Tipo float vai de " + float.MinValue + " ate " + float.MaxValue);      // Utiliza 32byte 7 numero depois do ponto
            Console.WriteLine("O Tipo double vai de " + double.MinValue + " ate " + double.MaxValue);       // Utiliza 64byte, e 15 numero depois do ponto
            Console.WriteLine("O Tipo float vai de " + decimal.MinValue + " ate " + decimal.MaxValue);      // Utiliza 128byte e 28 numeros depois do ponto
            // Valores Logicos
            Console.WriteLine("O Tipo bool aceita " + bool.FalseString + " ou " + bool.TrueString);      // Ele ira responder somente Verdadeiro ou Falso


            Console.ReadKey();
        }
    }
}
