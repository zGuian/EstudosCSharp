﻿namespace M01A08C
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Digite um numero para saber o dobro dele: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int d = n * 2;
            Console.WriteLine("O Dobro de " + n + " é " + d );
            Console.ReadKey();

            //Tentando converter
            /* 
             * int num = 0;
             * int.TryParse(Console.ReadLine(), out num);
             */
        }
    }
}
