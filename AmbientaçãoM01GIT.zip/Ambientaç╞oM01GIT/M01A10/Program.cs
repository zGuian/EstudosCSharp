﻿namespace M01A010
{
    class Program
    {
        static void Main(string[] args)
        {
            int dia = DateTime.Now.Day;
            int mes = DateTime.Now.Month;
            int ano = DateTime.Now.Year;
            Console.WriteLine("O ano atual é " + dia + "/" + mes + "/" + ano);

            int hora = DateTime.Now.Hour;
            int min = DateTime.Now.Minute;
            int seg = DateTime.Now.Second;
            Console.WriteLine("A hora atual é " + hora + ":" + min + ":" + seg);
        }
    }
}