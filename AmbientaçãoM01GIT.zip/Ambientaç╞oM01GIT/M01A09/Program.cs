﻿namespace M01A09
{
    class Program
    {
        static void Main(string[] args)
        {
            Random gerador = new Random();
            int n = gerador.Next(10,15); //Ultimo numero sempre perde uma unidade no exemplo atrás seria entre 10 e 14 o gerador
            Console.WriteLine("Acabei de gerar o numero " + n);
            Console.ReadKey();
        }
    }
}