﻿namespace M01A012A
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Qual é seu nome? ");
            string nome = Console.ReadLine();
            Console.WriteLine($"Olá {nome}! tudo bem?");
            //colocar "$" na frente das aspas para declarar interpolação
            //usamos "@" para declarar que não queremos fazer a interpolação
        }
    }
}