﻿namespace M01A04
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Regras para criar variaveis
             * 
             * Começar com letra ou sublinhado ou @
             * Maiúsculas e minúsculas fazem diferença (recomendado sempre minuscula)
             * Só usa letra, numero e sublinhado
             * Podemos usar acentos
             * Não pode conter espaços (utilizar "_" ou KermalCase (KemalCase = SeparadoPorLetrasMaiusculas)
             * não pode ser uma palavra reservada a programação (ex: int = int) */


            // Declaração de variaveis (colocar o tipo e o valor)
            byte n = 255;

            Console.WriteLine("A variavel n tem " + n);
            Console.WriteLine("n é do tipo " + n.GetType());

            byte idade = 19;
            Console.WriteLine("Eu tenho " + idade);
            Console.WriteLine("idade é do tipo " + idade.GetType());

            string nome = "Zé";
            Console.WriteLine("Eu me chamo " + nome);
            Console.WriteLine("zé é do tipo " + nome.GetType());

            bool casado = false;
            Console.WriteLine("Você é casado? " + casado);
            Console.WriteLine("casado é do tipo " + casado.GetType());

            float media = 9.5f; // Sempre que utilizar float tem que coloca "F" no final
            Console.WriteLine("A media da escolá é " + media);
            Console.WriteLine("media é do tipo " + media.GetType());

            decimal estrela = 4.2103907883241M; // Sempre que utilizar decimal tem que coloca "M" no final
            Console.WriteLine("a quantidade de estrelas no ceu é " + estrela);
            Console.WriteLine("estrela é do tipo " + estrela.GetType());


            Console.ReadKey();
        }
    }
}