﻿namespace M01A08E
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Digite um numero: ");
            int n = 0;
            int.TryParse(Console.ReadLine(), out n);
            int d = 2 * n;
            Console.WriteLine("O dobro de " + n + " é de " + d);
            Console.ReadKey();
        }

    }
}