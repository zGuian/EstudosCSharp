namespace M01A08B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt16(txtBox.Text);
            int d = n * 2;
            lblMsg.Text = "O dobro de " + n + " � de " + d;
            lblMsg.Visible = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
    }
}