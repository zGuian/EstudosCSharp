﻿class Program
{
    static void Main(string[] args)
    {
        string nome = "Guia";
        float salario = 555.7556f;
        Console.WriteLine($"Olá {nome, 20}"); //colocando negativo ele conta para direita
        Console.WriteLine($"O {nome} ganha {salario:c2} por mês"); /*adicionando o ":c" formata para valor monetario 
        caso queria colocar mais casa monetaria so colocar a quantidade de numero depois da virgula*/
        

        /* :c Monetario (currency)
         * :d Decimal (inteiro)
         * :n Númerio (real) da pra colocar o zero na frente caso precise
         * :e Cientifico
         * :x Hexadecimal
         * */
    }
}
