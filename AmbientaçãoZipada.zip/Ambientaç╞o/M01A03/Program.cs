﻿class Program
{
    static void Main(string[] args)
    {
        var t = "Oi";
        Console.WriteLine(t);
    }
}
